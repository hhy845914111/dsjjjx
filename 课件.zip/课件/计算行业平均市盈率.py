# -*- coding: utf-8 -*-
"""
Created on Thu Nov 17 17:26:15 2016

@author: ZG
"""

#计算上市公司行业市值排名

import sys
reload(sys)
sys.setdefaultencoding('utf-8')


import pandas as pd
#平均市盈率等于总市值/总利润

china=pd.read_csv("../data/china_stockA.csv",encoding='gbk')
#利润计算
for i in china.index:
    china.ix[i,'profit']=china.ix[i,'esp'] * china.ix[i,'totals'] * 4 / 3


hangye=china.ix[:,'industry']
hangye=set(hangye)
#计算加权市盈率的均值
all_profit=0
all_mv=0
for h in hangye:
    hy=china[china['industry']==h]
    hy_profit=0
    hy_mv=0
    for i in hy.index:
        if   hy.ix[i,'price'] >0:      
            hy_profit = hy_profit + hy.ix[i,'profit']
            hy_mv = hy_mv + hy.ix[i,'mv']
            all_profit = all_profit + hy.ix[i,'profit']
            all_mv = all_mv + hy.ix[i,'mv']
    if hy_profit>0:        
        hy_pe = hy_mv / hy_profit * 10000
        print "%s的平均市盈率为%.2f" % (h,hy_pe)
if all_profit>0:
    all_pe=all_mv/all_profit*10000
    print "A股市场的平均PE为", all_pe