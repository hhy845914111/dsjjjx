# -*- coding: utf-8 -*-
"""
Created on Thu Nov 17 09:55:14 2016

@author: ZG
"""

#处理中文报错必备
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

import tushare as ts
import pandas as pd
import datetime

#获得最近一个交易日股票的收盘价
def get_price(code):
    day=(datetime.datetime.now() - datetime.timedelta(days = 1))
    y = day.strftime("%Y-%m-%d") 
    try:    
        d=ts.get_hist_data(code,start=y,end=y)
        price=d.ix[y,'close']
        print code,price
    except:
        d=ts.get_hist_data(code)
        daymax=d.index.max()
        price=d.ix[daymax,'close']
    return  price

#将整数代码转换为字符串代码
def get_code(code):
    c1=str(code)
    while len(c1)<6:
        c1='0'+c1
    return c1

#1.获取所有股票信息
#china=ts.get_stock_basics()
#china['price']=0
#china.to_csv("china_stockA.csv",encoding="gbk",index=False)

#2.获得股票价格，插入或更新到china_stockA.csv中
china=pd.read_csv("china_stockA.csv",encoding='gbk')
for i in china.index:
    code=china.ix[i,'code']
    code=get_code(code)
    price=china.ix[i,'price']
    if price<=0:
        try:        
            price=get_price(code)
            china.ix[i,'price']=price
        except:
            china.to_csv("china_stockA.csv",encoding="gbk",index=False)
china.to_csv("china_stockA.csv",encoding="gbk",index=False)
    