#黑色星期五测试
import pandas as pd
import pandas.io.data as web
import scipy.stats as stats 

'''
start = "2006-09-01"
end = "2016-09-01"
df = web.DataReader("AAPL", 'yahoo', start, end)
df.to_csv('data/aapl.csv');
'''
df=pd.read_csv('data/aapl.csv',parse_dates ='Date' , index_col='Date')

#print df

L=df[['Adj Close']]
L=L.diff() #L=L.pct_change()
L=L.dropna()

for i in L.index:
    delta=L.ix[i,'Adj Close']
    da=i.date()

a=pd.DataFrame(columns=['A'])
b=pd.DataFrame(columns=['A'])
for i in L.index:
    delta=L.ix[i,'Adj Close']
    da=i.date()
    w=da.isoweekday()
    d=da.day
    if w==5 and d==13:
        if delta>0:
            a1=pd.DataFrame({'A':[1]})
            a=a.append(a1)
        elif delta<0:
            a1=pd.DataFrame({'A':[0]})
            a=a.append(a1)
    else:
        if delta>0:
            b1=pd.DataFrame({'A':[1]})
            b=b.append(b1)
        elif delta<0:
            b1=pd.DataFrame({'A':[0]})
            b=b.append(b1)
            
print start,"-",end,"之间"


print "一共出现黑五的次数：",len(a)
print "上涨次数%d次，概率%.2f " % (len(a[a['A']>=0]), a.mean())
print "下跌次数%d次，概率%.2f " % (len(a[a['A']<0]), 1-a.mean())

print "参照组出现黑五的次数：",len(a)
print "参照组上涨次数%d次，概率%.2f " % (len(b[b['A']>=0]), b.mean())
print "参照组下跌次数%d次，概率%.2f " % (len(b[b['A']<0]), 1-b.mean())


p1=stats.levene(a['A'],b['A'])[1]
print "方差齐次性检验的P值是%.2f" % p1

if(p1>0.05):
    p2=stats.ttest_ind(a['A'],b['A'])[1]
else:
    p2=stats.ttest_ind(a['A'],b['A'],equal_var=False)[1]
print "T检验P值的结果是%.2f" % p2
k=1
if p<=0.05:
   print "苹果公司股票价格黑五的涨跌的概率与非黑五具有显著差异，下跌概率相对多%.2f" % (-a.mean()+b.mean())
else:
    print "苹果公司股票价格黑五的涨跌的概率与非黑五无显著差异"

