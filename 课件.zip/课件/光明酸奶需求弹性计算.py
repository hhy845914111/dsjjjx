import tushare as ts
import pandas as pd
from statsmodels.formula.api import ols
import math
#https://mall.datayes.com/datapreview/969

ts.set_token('a7ad80eed31ec1189dcad686d141df5c9ce1373d456672592158006fb62e3f01')
fd = ts.Macro()

def initdf1(df1,col):
    df11=df1[['periodDate','dataValue']]
    df12=df11.rename(columns={'dataValue':col,'periodDate':'date'})
    df13=df12.set_index('date')
    return df13
#1.光明安慕希数据导入
df1 = fd.EcommerceDataGuangming(indicID='E020800035') 
df2 = fd.EcommerceDataGuangming(indicID='E020800034') 

df1=initdf1(df1,'gm_sales')
df2=initdf1(df2,'gm_vol')
df3=pd.concat([df1,df2],axis=1)

#4.剔除双十一后异常数据
df6=df3[df3.index<'2015-11-11']

#5.计算价格字段
df6['gm_price']=df6['gm_sales']/df6['gm_vol']

#7.剔除异常数据
df6=df6[df6['gm_price']<80]

print df6.corr()


#6.计算光明莫斯利安的价格需求弹性 Ln(gm_sales)=a*ln(gm_price)+b
df6['log_gm_price']=0
for d in df6.index:
    df6.ix[d,'log_gm_price']=math.log(df6.ix[d,'gm_price'])
    df6.ix[d,'log_gm_vol']=math.log(df6.ix[d,'gm_vol'])
df6['log_yl_price']=0
   
result = ols(formula="log_gm_vol ~ log_gm_price ", data=df6).fit()
print result.summary()
