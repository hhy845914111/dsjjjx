# -*- coding: utf-8 -*-
"""
Created on Thu Nov 17 16:38:32 2016

@author: ZG
"""
#计算上市公司行业市值排名

import sys
reload(sys)
sys.setdefaultencoding('utf-8')


import pandas as pd

china=pd.read_csv("china_stockA.csv",encoding='gbk')
#市值计算
zong=0
for i in china.index:
    mv = china.ix[i,'price'] * china.ix[i,'totals'] /10000   
    china.ix[i,'mv']=mv
    zong=zong+mv
print "A股总市值为%f（亿元）" % zong
hangye = china.ix[:,'industry']
hangye = set(hangye) #去掉重复
for h in hangye:
    hy=china[china['industry']==h]
    #计算hy行业排名
    hy=hy.sort(columns=['mv'], ascending=[0])
    k=1
    hzong=0
    for i in hy.index:
        china.ix[i,'mv_hy']=k
        k=k+1
        hzong=hzong+hy.ix[i,'mv']
    print "%s行业有%d家公司，总市值%.2f亿元,占比%.2f%%" % (h,len(hy),hzong, hzong/zong*100)
china.to_csv('china_stockA.csv', encoding='gbk', index=False)        

