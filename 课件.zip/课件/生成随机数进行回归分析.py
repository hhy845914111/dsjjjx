# -*- coding: utf-8 -*-
"""
Created on Thu Nov 24 20:39:33 2016

@author: ZG
"""
import numpy as np
from statsmodels.formula.api import ols
import pandas as pd

sample=1000
#df=pd.DataFrame(np.random.randn(sample,5),columns=['Y','X1','X2','X3','X4'])

#按协方差矩阵产生随机数
mean=[1,2,3,4,5]
cov=[
     [1,0,0,0,0],
     [0,1,0,0,0],
     [0,0,1,0,0],
     [0,0,0,1,0],
     [0,0,0,0,1],
    ]



df=pd.DataFrame(np.random.multivariate_normal(mean, cov, sample),columns=['Y','X1','X2','X3','X4'])

print df
print df.corr()

model = ols(formula='Y ~ X1 + X2 + X3 + X4',data=df)
results = model.fit()
print(results.summary())
